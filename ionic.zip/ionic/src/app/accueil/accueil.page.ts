import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-accueil',
  templateUrl: './accueil.page.html',
  styleUrls: ['./accueil.page.scss'],
})
export class AccueilPage implements OnInit {

  pays : any [] = [];
 

  constructor() { }
  
  ngOnInit() {
  }
  getnom (obj: any){
    localStorage.setItem('key', JSON.stringify(obj)) 
  
   
  }

}
