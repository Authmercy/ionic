import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-onglet',
  templateUrl: './onglet.page.html',
  styleUrls: ['./onglet.page.scss'],
})
export class OngletPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
